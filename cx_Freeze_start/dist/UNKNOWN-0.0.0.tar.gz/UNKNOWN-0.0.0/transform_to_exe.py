from cx_Freeze import setup, Executable

setup(
    author = "David-Ioannis Gugea",
    author_email = "davidgugea@yahoo.com",
    executables= [Executable("calc.py")]
)
