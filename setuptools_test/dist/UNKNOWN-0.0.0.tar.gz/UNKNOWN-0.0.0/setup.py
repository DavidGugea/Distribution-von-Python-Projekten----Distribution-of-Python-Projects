from setuptools import setup, find_packages

setup(
        author = "David-Ioannis Gugea",
        author_email = "davidgugea@yahoo.com",
        packages = find_packages()
)
